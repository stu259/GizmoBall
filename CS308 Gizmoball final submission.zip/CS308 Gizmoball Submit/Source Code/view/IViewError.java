package view;

public interface IViewError {

	public void errorPopup(String errorMessage);

}
