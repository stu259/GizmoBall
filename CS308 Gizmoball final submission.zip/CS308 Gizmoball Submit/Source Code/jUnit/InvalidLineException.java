package jUnit;

public class InvalidLineException extends Exception {

}
